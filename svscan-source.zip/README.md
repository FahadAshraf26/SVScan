# SVScan

A small, self-contained tool for **ACCEO Smart Vendor** retail POS. It runs on
the Smart Vendor server and lets any phone on the same Wi‑Fi look up an item's
**price and quantity on hand** by scanning or typing a barcode / item # /
reorder #, and (optionally) print corrected shelf tags on a TLP 2824 label
printer.

It is **read‑only and passwordless**: it never logs into the live MySQL
database and never modifies anything. It reads a copy of a few MyISAM tables
directly from disk every few minutes and serves lookups from memory.

## Status

| Feature | State |
|---|---|
| Price / quantity lookup (manual entry) | ✅ working |
| Reorder‑number search (incl. alternate suppliers) | ✅ working |
| Phone camera scanning | 🚧 hidden (flag `FEATURES.camera`) |
| Label printing (EPL2 to TLP 2824) | 🚧 hidden (flag `FEATURES.printing`) |

Camera and printing are implemented but disabled in the UI while they're being
sorted out on-site (camera needs HTTPS + a supported browser; the second
printer was a Windows network‑sharing issue). Re‑enable either by flipping the
flag at the top of the `<script>` in [`web/index.html`](web/index.html):

```js
const FEATURES = { camera: false, printing: false };
```

## How it works

- **Data source.** Smart Vendor stores its data in MySQL 5.5 (MyISAM, latin1).
  Rather than authenticate, SVScan copies just the tables it needs and parses
  the fixed‑row `.MYD` files directly:
  - `stkreport` — item identity (UPC/UPC2/UPC3, name, stock #, reorder #, dept…)
  - `stkprice`  — live sell price, sale price + window, and `TOTONHAND` qty (per store)
  - `stkprod`   — per‑supplier reorder numbers (so any reorder # is searchable)
- The MyISAM static‑row reader ([`reader.go`](reader.go)) was calibrated against
  real Smart Vendor files: `CHAR` (latin1), `DECIMAL(18,4)` (packed "new decimal"),
  legacy 8‑byte `DATETIME` (`YYYYMMDDHHMMSS`), `TINYINT`, deleted‑record flags,
  and the null‑byte header. Record lengths are validated (`fileSize % recLen == 0`)
  plus value sanity checks, so a schema/version mismatch fails loudly instead of
  showing wrong prices.
- Everything is indexed in memory by every barcode / id form; lookups are instant.
  A background refresh re-reads the tables on an interval.
- The phone UI is a single embedded HTML page. Camera scanning (when enabled)
  uses the native `BarcodeDetector` where available and falls back to
  `html5-qrcode`. Camera access requires a secure origin, so the server serves
  HTTPS with a self‑signed cert (generated on first run, covering the LAN IP).
- Printing (when enabled) generates **EPL2** matching Smart Vendor's own
  `Elt2824_Stk_1up_1Price_Shelf_ReorderNo` template and sends it **RAW** to the
  Windows print spooler ([`printer_windows.go`](printer_windows.go)).

## Build

Requires Go 1.24+.

```bash
# Windows (deploy target)
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -ldflags "-s -w" -o SVScan.exe .

# Linux (local dev; printing writes the EPL to a file instead of a printer)
go build -o svscan_linux .
```

### Run (dev, non-Windows)

```bash
SVSCAN_DATA=/path/with/svMain SVSCAN_WORK=/tmp/svscan ./svscan_linux
# then open https://localhost:8443
```

On Windows it auto-detects `C:\Smartwin\Data`, works out of `C:\SVScan\`, and
prints the phone URL to the console.

## Configuration

`svscan_config.json` (in the work dir) is created on first run:

| key | meaning | default |
|---|---|---|
| `smartwinData` | folder containing the `svMain` subfolder | auto-detect `C:\Smartwin\Data` |
| `storeNo` | store number to price against (trimmed) | `1` |
| `httpPort` / `httpsPort` | ports (HTTP redirects to HTTPS) | `8080` / `8443` |
| `refreshMinutes` | how often to re-read the tables | `3` |
| `printerName` | Windows printer / UNC share for the TLP 2824 | *(unset)* |
| `labelWidth` | EPL `q` width in dots | `450` |

## Layout

```
main.go              entrypoint, HTTPS server, embeds web/
server.go            HTTP handlers + refresh loop
reader.go            MyISAM fixed-row reader (stkprice / stkreport / stkprod)
model.go             Item model, in-memory index, barcode normalization
epl.go               EPL2 shelf-tag + test-label generation
config.go            config load/save + path auto-detect
tlsgen.go            self-signed cert covering the LAN IP
printer_windows.go   RAW printing via winspool (Windows)
printer_stub.go      dev stub (writes EPL to a file)
web/index.html       phone UI (single file)
web/html5-qrcode.min.js   bundled camera fallback
```

Not affiliated with ACCEO / Smart Vendor. Reads its data files read‑only.
