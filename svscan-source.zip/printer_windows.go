//go:build windows

package main

import (
	"fmt"
	"syscall"
	"unsafe"
)

var (
	winspool           = syscall.NewLazyDLL("winspool.drv")
	procEnumPrintersW  = winspool.NewProc("EnumPrintersW")
	procOpenPrinterW   = winspool.NewProc("OpenPrinterW")
	procClosePrinter   = winspool.NewProc("ClosePrinter")
	procStartDocPrinim = winspool.NewProc("StartDocPrinterW")
	procEndDocPrinter  = winspool.NewProc("EndDocPrinter")
	procStartPagePrint = winspool.NewProc("StartPagePrinter")
	procEndPagePrinter = winspool.NewProc("EndPagePrinter")
	procWritePrinter   = winspool.NewProc("WritePrinter")
)

const (
	printerEnumLocal       = 0x00000002
	printerEnumConnections = 0x00000004
)

type printerInfo4 struct {
	PrinterName *uint16
	ServerName  *uint16
	Attributes  uint32
}

type docInfo1 struct {
	DocName    *uint16
	OutputFile *uint16
	Datatype   *uint16
}

func listPrinters() ([]string, error) {
	flags := uintptr(printerEnumLocal | printerEnumConnections)
	var needed, returned uint32
	// first call: size
	procEnumPrintersW.Call(flags, 0, 4, 0, 0,
		uintptr(unsafe.Pointer(&needed)), uintptr(unsafe.Pointer(&returned)))
	if needed == 0 {
		return nil, nil
	}
	buf := make([]byte, needed)
	r1, _, e := procEnumPrintersW.Call(flags, 0, 4,
		uintptr(unsafe.Pointer(&buf[0])), uintptr(needed),
		uintptr(unsafe.Pointer(&needed)), uintptr(unsafe.Pointer(&returned)))
	if r1 == 0 {
		return nil, fmt.Errorf("EnumPrinters failed: %v", e)
	}
	var out []string
	info := (*[4096]printerInfo4)(unsafe.Pointer(&buf[0]))
	for i := 0; i < int(returned); i++ {
		if info[i].PrinterName != nil {
			out = append(out, utf16ToString(info[i].PrinterName))
		}
	}
	return out, nil
}

func rawPrint(printerName string, data []byte) error {
	if printerName == "" {
		return fmt.Errorf("no printer selected")
	}
	pName, _ := syscall.UTF16PtrFromString(printerName)
	var h syscall.Handle
	r1, _, e := procOpenPrinterW.Call(uintptr(unsafe.Pointer(pName)),
		uintptr(unsafe.Pointer(&h)), 0)
	if r1 == 0 {
		return fmt.Errorf("OpenPrinter(%q) failed: %v", printerName, e)
	}
	defer procClosePrinter.Call(uintptr(h))

	docName, _ := syscall.UTF16PtrFromString("SVScan Shelf Tag")
	datatype, _ := syscall.UTF16PtrFromString("RAW")
	di := docInfo1{DocName: docName, OutputFile: nil, Datatype: datatype}
	r1, _, e = procStartDocPrinim.Call(uintptr(h), 1, uintptr(unsafe.Pointer(&di)))
	if r1 == 0 {
		return fmt.Errorf("StartDocPrinter failed: %v", e)
	}
	defer procEndDocPrinter.Call(uintptr(h))

	r1, _, e = procStartPagePrint.Call(uintptr(h))
	if r1 == 0 {
		return fmt.Errorf("StartPagePrinter failed: %v", e)
	}
	defer procEndPagePrinter.Call(uintptr(h))

	var written uint32
	r1, _, e = procWritePrinter.Call(uintptr(h),
		uintptr(unsafe.Pointer(&data[0])), uintptr(len(data)),
		uintptr(unsafe.Pointer(&written)))
	if r1 == 0 {
		return fmt.Errorf("WritePrinter failed: %v", e)
	}
	if int(written) != len(data) {
		return fmt.Errorf("short write to printer: %d of %d", written, len(data))
	}
	return nil
}

func utf16ToString(p *uint16) string {
	if p == nil {
		return ""
	}
	var s []uint16
	ptr := unsafe.Pointer(p)
	for i := 0; ; i++ {
		c := *(*uint16)(unsafe.Pointer(uintptr(ptr) + uintptr(i)*2))
		if c == 0 {
			break
		}
		s = append(s, c)
	}
	return syscall.UTF16ToString(s)
}
