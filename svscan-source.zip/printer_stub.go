//go:build !windows

package main

import (
	"fmt"
	"os"
	"path/filepath"
)

// Non-Windows build: used for development/testing. "Printing" writes the raw
// EPL to a file so the output can be inspected, and a couple of fake printers
// are listed.
func listPrinters() ([]string, error) {
	return []string{"(dev) TLP 2824", "(dev) EPSON TM-T88V Receipt"}, nil
}

func rawPrint(printerName string, data []byte) error {
	p := filepath.Join(workDir(), "last_label.epl")
	if err := os.WriteFile(p, data, 0644); err != nil {
		return err
	}
	fmt.Printf("[dev] would print %d bytes to %q -> wrote %s\n", len(data), printerName, p)
	return nil
}
