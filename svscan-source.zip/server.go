package main

import (
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"sync"
	"time"
)

type Server struct {
	cfg     Config
	cfgMu   sync.Mutex
	catalog *Catalog
}

func writeJSON(w http.ResponseWriter, code int, v interface{}) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	_ = json.NewEncoder(w).Encode(v)
}

func (s *Server) getCfg() Config {
	s.cfgMu.Lock()
	defer s.cfgMu.Unlock()
	return s.cfg
}

func (s *Server) routes() *http.ServeMux {
	mux := http.NewServeMux()

	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		b, _ := webFS.ReadFile("web/index.html")
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Write(b)
	})

	mux.HandleFunc("/html5-qrcode.min.js", func(w http.ResponseWriter, r *http.Request) {
		b, err := webFS.ReadFile("web/html5-qrcode.min.js")
		if err != nil {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "application/javascript")
		w.Header().Set("Cache-Control", "public, max-age=86400")
		w.Write(b)
	})

	mux.HandleFunc("/api/status", func(w http.ResponseWriter, r *http.Request) {
		count, loaded, errStr := s.catalog.stats()
		cfg := s.getCfg()
		writeJSON(w, 200, map[string]interface{}{
			"version":    version,
			"itemCount":  count,
			"loadedAt":   loaded.Format(time.RFC3339),
			"loadError":  errStr,
			"store":      cfg.StoreNo,
			"printer":    cfg.PrinterName,
			"dataPath":   cfg.SmartwinData,
			"refreshMin": cfg.RefreshMinutes,
			"labelWidth": cfg.LabelWidth,
			"ip":         primaryIP(),
			"httpsPort":  cfg.HTTPSPort,
		})
	})

	mux.HandleFunc("/api/lookup", func(w http.ResponseWriter, r *http.Request) {
		code := r.URL.Query().Get("code")
		if code == "" {
			writeJSON(w, 400, map[string]interface{}{"error": "missing code"})
			return
		}
		it, ok := s.catalog.lookup(code)
		if !ok {
			writeJSON(w, 200, map[string]interface{}{"found": false, "scanned": code})
			return
		}
		writeJSON(w, 200, map[string]interface{}{"found": true, "scanned": code, "item": it})
	})

	mux.HandleFunc("/api/printers", func(w http.ResponseWriter, r *http.Request) {
		ps, err := listPrinters()
		if err != nil {
			writeJSON(w, 200, map[string]interface{}{"printers": []string{}, "error": err.Error(), "selected": s.getCfg().PrinterName})
			return
		}
		writeJSON(w, 200, map[string]interface{}{"printers": ps, "selected": s.getCfg().PrinterName})
	})

	mux.HandleFunc("/api/settings", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			writeJSON(w, 405, map[string]interface{}{"error": "POST only"})
			return
		}
		var body struct {
			PrinterName *string `json:"printerName"`
			StoreNo     *string `json:"storeNo"`
			LabelWidth  *int    `json:"labelWidth"`
		}
		if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
			writeJSON(w, 400, map[string]interface{}{"error": "bad json"})
			return
		}
		s.cfgMu.Lock()
		if body.PrinterName != nil {
			s.cfg.PrinterName = *body.PrinterName
		}
		reIndex := false
		if body.StoreNo != nil && *body.StoreNo != "" {
			s.cfg.StoreNo = *body.StoreNo
			reIndex = true
		}
		if body.LabelWidth != nil && *body.LabelWidth > 0 {
			s.cfg.LabelWidth = *body.LabelWidth
		}
		cfg := s.cfg
		s.cfgMu.Unlock()
		_ = saveConfig(cfg)
		if reIndex {
			go s.refresh()
		}
		writeJSON(w, 200, map[string]interface{}{"ok": true})
	})

	mux.HandleFunc("/api/print", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			writeJSON(w, 405, map[string]interface{}{"error": "POST only"})
			return
		}
		var body struct {
			StockNo string `json:"stockNo"`
			Qty     int    `json:"qty"`
			UseSale bool   `json:"useSale"`
			Printer string `json:"printer"`
		}
		if err := json.NewDecoder(r.Body).Decode(&body); err != nil {
			writeJSON(w, 400, map[string]interface{}{"error": "bad json"})
			return
		}
		it, ok := s.catalog.byStockNo(body.StockNo)
		if !ok {
			writeJSON(w, 404, map[string]interface{}{"error": "item not found"})
			return
		}
		cfg := s.getCfg()
		printer := body.Printer
		if printer == "" {
			printer = cfg.PrinterName
		}
		if printer == "" {
			writeJSON(w, 400, map[string]interface{}{"error": "No printer selected. Pick your TLP 2824 in Settings."})
			return
		}
		epl := buildEPL(it, LabelOptions{Qty: body.Qty, UseSale: body.UseSale, Width: cfg.LabelWidth})
		if err := rawPrint(printer, epl); err != nil {
			writeJSON(w, 500, map[string]interface{}{"error": err.Error()})
			return
		}
		writeJSON(w, 200, map[string]interface{}{"ok": true, "printed": it.Name, "qty": body.Qty})
	})

	mux.HandleFunc("/api/testprint", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			writeJSON(w, 405, map[string]interface{}{"error": "POST only"})
			return
		}
		var body struct {
			Printer string `json:"printer"`
		}
		_ = json.NewDecoder(r.Body).Decode(&body)
		cfg := s.getCfg()
		printer := body.Printer
		if printer == "" {
			printer = cfg.PrinterName
		}
		if printer == "" {
			writeJSON(w, 400, map[string]interface{}{"error": "Choose a printer first."})
			return
		}
		if err := rawPrint(printer, buildTestEPL(printer, cfg.LabelWidth)); err != nil {
			writeJSON(w, 500, map[string]interface{}{"error": err.Error()})
			return
		}
		writeJSON(w, 200, map[string]interface{}{"ok": true, "printer": printer})
	})

	mux.HandleFunc("/api/reload", func(w http.ResponseWriter, r *http.Request) {
		go s.refresh()
		writeJSON(w, 200, map[string]interface{}{"ok": true})
	})

	return mux
}

// ---- catalog refresh ----

func copyFile(src, dst string) error {
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	fi, _ := in.Stat()
	size := fi.Size()
	if err := os.MkdirAll(filepath.Dir(dst), 0755); err != nil {
		return err
	}
	out, err := os.Create(dst)
	if err != nil {
		return err
	}
	defer out.Close()
	_, err = io.CopyN(out, in, size) // snapshot: copy the size we observed
	if err == io.EOF {
		err = nil
	}
	return err
}

func (s *Server) refresh() {
	cfg := s.getCfg()
	svMain := filepath.Join(cfg.SmartwinData, "svMain")
	snap := filepath.Join(workDir(), "snap")

	setErr := func(e string) {
		s.catalog.mu.Lock()
		s.catalog.err = e
		s.catalog.mu.Unlock()
		fmt.Println("[refresh] error:", e)
	}

	priceSrc := filepath.Join(svMain, "stkprice.MYD")
	repSrc := filepath.Join(svMain, "stkreport.MYD")
	prodSrc := filepath.Join(svMain, "stkprod.MYD")
	priceDst := filepath.Join(snap, "stkprice.MYD")
	repDst := filepath.Join(snap, "stkreport.MYD")
	prodDst := filepath.Join(snap, "stkprod.MYD")

	if err := copyFile(priceSrc, priceDst); err != nil {
		setErr("cannot read stkprice.MYD: " + err.Error())
		return
	}
	if err := copyFile(repSrc, repDst); err != nil {
		setErr("cannot read stkreport.MYD: " + err.Error())
		return
	}
	// stkprod is optional (extra reorder numbers); don't fail the whole load if missing.
	reorders := map[string][]string{}
	if err := copyFile(prodSrc, prodDst); err == nil {
		if r, err := readStkprod(prodDst); err == nil {
			reorders = r
		} else {
			fmt.Println("[refresh] stkprod skipped:", err)
		}
	}

	prices, err := readStkprice(priceDst, cfg.StoreNo)
	if err != nil {
		setErr(err.Error())
		return
	}
	items, err := readStkreport(repDst, prices, reorders)
	if err != nil {
		setErr(err.Error())
		return
	}
	idx := buildIndex(items)

	s.catalog.mu.Lock()
	s.catalog.items = items
	s.catalog.byCode = idx
	s.catalog.count = len(items)
	s.catalog.loadedAt = time.Now()
	s.catalog.err = ""
	s.catalog.mu.Unlock()

	_ = os.Remove(priceDst)
	_ = os.Remove(repDst)
	_ = os.Remove(prodDst)
	fmt.Printf("[refresh] loaded %d items (%d priced, %d w/extra reorder#) for store %s\n", len(items), len(prices), len(reorders), cfg.StoreNo)
}

func (s *Server) refreshLoop() {
	for {
		d := time.Duration(s.getCfg().RefreshMinutes) * time.Minute
		if d < time.Minute {
			d = time.Minute
		}
		time.Sleep(d)
		s.refresh()
	}
}
