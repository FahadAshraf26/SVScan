package main

import (
	"fmt"
	"math/big"
	"os"
	"strings"
)

// ---- MyISAM fixed(static)-row reader, calibrated against real Smart Vendor MySQL 5.5 files ----
//
// Static row layout (verified against real lookup.MYD / labeldet.MYD):
//   - nullBytes bytes at the start of each record; bit 0 of byte 0 = "record in use" (1) / deleted (0).
//     nullBytes = ceil((#nullableColumns + 1) / 8).
//   - Then every column stored full-width in declaration order:
//       CHAR(n) latin1 : n bytes, space padded (trailing spaces trimmed).
//       DECIMAL(18,4)  : 9 bytes, MySQL "new decimal" packed format.
//       DATETIME       : 8 bytes, little-endian int = YYYYMMDDHHMMSS (legacy, pre-5.6).
//       TIMESTAMP      : 4 bytes.
//       TINYINT        : 1 byte.
//       BIGINT         : 8 bytes.
//
// We only decode the columns we need, addressed by absolute byte offset within the record.

type colRef struct {
	off int // absolute offset within a record
	w   int // width in bytes
}

// Offsets/widths below were computed from the live .frm schema (SV 8.0.46) and validated
// by (recLen % fileSize == 0) plus value-sanity checks at load time.
type stkpriceLayout struct {
	nullBytes int
	recLen    int
	STOCKNO   colRef
	STORENO   colRef
	SELLPRICE colRef
	SALEPRICE colRef
	LISTPRICE colRef
	SALESTART colRef
	SALEEND   colRef
	STATUS    colRef
	TOTONHAND colRef
}

type stkreportLayout struct {
	nullBytes   int
	recLen      int
	STOCKNO     colRef
	STOCKID     colRef
	UPC         colRef
	UPC2        colRef
	UPC3        colRef
	NAME        colRef
	NAME2       colRef
	REORDERNO   colRef
	DEPTNAME    colRef
	SUBDEPTNAME colRef
	SUPPNAME    colRef
	TOTQOH      colRef
}

var spL = stkpriceLayout{
	nullBytes: 27, recLen: 1898,
	STOCKNO:   colRef{63, 36},
	LISTPRICE: colRef{153, 9},
	SELLPRICE: colRef{162, 9},
	SALEPRICE: colRef{225, 9},
	SALESTART: colRef{234, 8},
	SALEEND:   colRef{242, 8},
	STORENO:   colRef{821, 36},
	STATUS:    colRef{857, 1},
	TOTONHAND: colRef{1349, 9},
}

var srL = stkreportLayout{
	nullBytes: 9, recLen: 2208,
	STOCKNO:     colRef{9, 36},
	STOCKID:     colRef{45, 14},
	UPC:         colRef{59, 20},
	NAME:        colRef{79, 30},
	NAME2:       colRef{109, 30},
	REORDERNO:   colRef{189, 36},
	SUPPNAME:    colRef{1223, 30},
	DEPTNAME:    colRef{1263, 30},
	SUBDEPTNAME: colRef{1293, 30},
	TOTQOH:      colRef{1692, 9},
	UPC2:        colRef{1729, 20},
	UPC3:        colRef{1749, 20},
}

func latin1Trim(b []byte) string {
	// decode latin1 -> utf8, trim trailing spaces/NULs
	var sb strings.Builder
	for _, c := range b {
		sb.WriteRune(rune(c))
	}
	return strings.TrimRight(sb.String(), " \x00")
}

func readLEInt(b []byte) int64 {
	var v int64
	for i := len(b) - 1; i >= 0; i-- {
		v = v<<8 | int64(b[i])
	}
	return v
}

var dig2bytes = []int{0, 1, 1, 2, 2, 3, 3, 4, 4}

// decodeDecimal decodes MySQL "new decimal" packed bytes for DECIMAL(precision,scale).
func decodeDecimal(b []byte, precision, scale int) float64 {
	if len(b) == 0 {
		return 0
	}
	buf := make([]byte, len(b))
	copy(buf, b)
	intg := precision - scale
	frac := scale
	sign := 1
	if buf[0]&0x80 != 0 {
		sign = 1
	} else {
		sign = -1
	}
	buf[0] ^= 0x80
	if sign < 0 {
		for i := range buf {
			buf[i] ^= 0xff
		}
	}
	idx := 0
	intVal := new(big.Int)
	ten := big.NewInt(10)
	pow := func(n int) *big.Int {
		return new(big.Int).Exp(ten, big.NewInt(int64(n)), nil)
	}
	intg0 := intg / 9
	intg0x := intg % 9
	if intg0x > 0 {
		n := dig2bytes[intg0x]
		val := bigFromBE(buf[idx : idx+n])
		idx += n
		intVal.Mul(intVal, pow(intg0x))
		intVal.Add(intVal, val)
	}
	for i := 0; i < intg0; i++ {
		val := bigFromBE(buf[idx : idx+4])
		idx += 4
		intVal.Mul(intVal, pow(9))
		intVal.Add(intVal, val)
	}
	fracVal := new(big.Int)
	fdig := 0
	frac0 := frac / 9
	frac0x := frac % 9
	for i := 0; i < frac0; i++ {
		val := bigFromBE(buf[idx : idx+4])
		idx += 4
		fracVal.Mul(fracVal, pow(9))
		fracVal.Add(fracVal, val)
		fdig += 9
	}
	if frac0x > 0 {
		n := dig2bytes[frac0x]
		val := bigFromBE(buf[idx : idx+n])
		idx += n
		fracVal.Mul(fracVal, pow(frac0x))
		fracVal.Add(fracVal, val)
		fdig += frac0x
	}
	f := new(big.Float).SetInt(intVal)
	if fdig > 0 {
		ff := new(big.Float).SetInt(fracVal)
		denom := new(big.Float).SetInt(pow(fdig))
		ff.Quo(ff, denom)
		f.Add(f, ff)
	}
	res, _ := f.Float64()
	return float64(sign) * res
}

func bigFromBE(b []byte) *big.Int {
	return new(big.Int).SetBytes(b)
}

// stkprod holds per-supplier reorder numbers, so an item can be found by ANY
// of its suppliers' reorder numbers (not just the primary one in stkreport).
type stkprodLayout struct {
	nullBytes int
	recLen    int
	STOCKNO   colRef
	REORDERNO colRef
}

var spdL = stkprodLayout{
	nullBytes: 3, recLen: 425,
	STOCKNO:   colRef{39, 36},
	REORDERNO: colRef{147, 36},
}

// readStkprod returns map[stockno][]reorderNo (deduped, non-empty).
func readStkprod(path string) (map[string][]string, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	rl := spdL.recLen
	if rl <= 0 || len(data)%rl != 0 {
		return nil, fmt.Errorf("stkprod.MYD size %d not a multiple of %d", len(data), rl)
	}
	col := func(rec []byte, c colRef) []byte { return rec[c.off : c.off+c.w] }
	out := make(map[string][]string)
	seen := make(map[string]bool)
	for p := 0; p+rl <= len(data); p += rl {
		rec := data[p : p+rl]
		if rec[0]&1 == 0 {
			continue
		}
		stockno := strings.TrimSpace(latin1Trim(col(rec, spdL.STOCKNO)))
		ro := strings.TrimSpace(latin1Trim(col(rec, spdL.REORDERNO)))
		if stockno == "" || ro == "" {
			continue
		}
		key := stockno + "\x00" + strings.ToUpper(ro)
		if seen[key] {
			continue
		}
		seen[key] = true
		out[stockno] = append(out[stockno], ro)
	}
	return out, nil
}

// priceRow is the subset we keep from stkprice for the configured store.
type priceRow struct {
	sell, sale, list, qty float64
	saleStart, saleEnd    int64
	status                string
}

// readStkprice returns map[stockno]priceRow for the configured store number.
func readStkprice(path, storeNo string) (map[string]priceRow, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	rl := spL.recLen
	if rl <= 0 || len(data)%rl != 0 {
		return nil, fmt.Errorf("stkprice.MYD size %d is not a multiple of record length %d (schema mismatch / different Smart Vendor version)", len(data), rl)
	}
	out := make(map[string]priceRow, len(data)/rl)
	col := func(rec []byte, c colRef) []byte { return rec[c.off : c.off+c.w] }
	sanity := 0
	for p := 0; p+rl <= len(data); p += rl {
		rec := data[p : p+rl]
		if rec[0]&1 == 0 {
			continue // deleted
		}
		store := strings.TrimSpace(latin1Trim(col(rec, spL.STORENO)))
		if store != storeNo {
			continue
		}
		stockno := strings.TrimSpace(latin1Trim(col(rec, spL.STOCKNO)))
		if stockno == "" {
			continue
		}
		pr := priceRow{
			sell:      decodeDecimal(col(rec, spL.SELLPRICE), 18, 4),
			sale:      decodeDecimal(col(rec, spL.SALEPRICE), 18, 4),
			list:      decodeDecimal(col(rec, spL.LISTPRICE), 18, 4),
			qty:       decodeDecimal(col(rec, spL.TOTONHAND), 18, 4),
			saleStart: readLEInt(col(rec, spL.SALESTART)),
			saleEnd:   readLEInt(col(rec, spL.SALEEND)),
			status:    latin1Trim(col(rec, spL.STATUS)),
		}
		if sanity < 50 {
			if pr.sell < 0 || pr.sell > 1e7 {
				return nil, fmt.Errorf("stkprice sanity check failed (implausible price %.2f) — schema/version mismatch", pr.sell)
			}
			sanity++
		}
		out[stockno] = pr
	}
	return out, nil
}

// readStkreport reads identity rows and joins price info, returning built Items.
func readStkreport(path string, prices map[string]priceRow, reorders map[string][]string) ([]*Item, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	rl := srL.recLen
	if rl <= 0 || len(data)%rl != 0 {
		return nil, fmt.Errorf("stkreport.MYD size %d is not a multiple of record length %d (schema mismatch / different Smart Vendor version)", len(data), rl)
	}
	col := func(rec []byte, c colRef) []byte { return rec[c.off : c.off+c.w] }
	items := make([]*Item, 0, len(data)/rl)
	for p := 0; p+rl <= len(data); p += rl {
		rec := data[p : p+rl]
		if rec[0]&1 == 0 {
			continue
		}
		stockno := strings.TrimSpace(latin1Trim(col(rec, srL.STOCKNO)))
		if stockno == "" {
			continue
		}
		it := &Item{
			StockNo:   stockno,
			StockID:   strings.TrimSpace(latin1Trim(col(rec, srL.STOCKID))),
			Name:      latin1Trim(col(rec, srL.NAME)),
			Name2:     latin1Trim(col(rec, srL.NAME2)),
			ReorderNo: strings.TrimSpace(latin1Trim(col(rec, srL.REORDERNO))),
			UPC:       strings.TrimSpace(latin1Trim(col(rec, srL.UPC))),
			UPC2:      strings.TrimSpace(latin1Trim(col(rec, srL.UPC2))),
			UPC3:      strings.TrimSpace(latin1Trim(col(rec, srL.UPC3))),
			Dept:      latin1Trim(col(rec, srL.DEPTNAME)),
			SubDept:   latin1Trim(col(rec, srL.SUBDEPTNAME)),
			Supp:      latin1Trim(col(rec, srL.SUPPNAME)),
			QtyReport: decodeDecimal(col(rec, srL.TOTQOH), 18, 4),
		}
		if pr, ok := prices[stockno]; ok {
			it.SellPrice = pr.sell
			it.SalePrice = pr.sale
			it.ListPrice = pr.list
			it.Qty = pr.qty
			it.SaleStart = pr.saleStart
			it.SaleEnd = pr.saleEnd
			it.hasPrice = true
		} else {
			it.Qty = it.QtyReport
		}
		// gather all reorder numbers: primary (from stkreport) + per-supplier (stkprod)
		roSet := map[string]bool{}
		if it.ReorderNo != "" {
			roSet[strings.ToUpper(it.ReorderNo)] = true
			it.AllReorders = append(it.AllReorders, it.ReorderNo)
		}
		for _, ro := range reorders[stockno] {
			if k := strings.ToUpper(ro); !roSet[k] {
				roSet[k] = true
				it.AllReorders = append(it.AllReorders, ro)
			}
		}
		items = append(items, it)
	}
	return items, nil
}
