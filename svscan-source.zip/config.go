package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"runtime"
)

type Config struct {
	SmartwinData   string `json:"smartwinData"`   // folder containing the svMain subfolder
	StoreNo        string `json:"storeNo"`        // trimmed store number, e.g. "1"
	HTTPPort       int    `json:"httpPort"`       // plain http (redirects to https)
	HTTPSPort      int    `json:"httpsPort"`      // https (phone camera requires this)
	RefreshMinutes int    `json:"refreshMinutes"` // how often to re-read the tables
	PrinterName    string `json:"printerName"`    // Windows printer for the TLP 2824
	LabelWidth     int    `json:"labelWidth"`     // EPL q width in dots
}

func defaultConfig() Config {
	return Config{
		SmartwinData:   "",
		StoreNo:        "1",
		HTTPPort:       8080,
		HTTPSPort:      8443,
		RefreshMinutes: 3,
		PrinterName:    "",
		LabelWidth:     450,
	}
}

func configPath() string {
	return filepath.Join(workDir(), "svscan_config.json")
}

func loadConfig() Config {
	c := defaultConfig()
	b, err := os.ReadFile(configPath())
	if err == nil {
		_ = json.Unmarshal(b, &c)
	}
	if c.SmartwinData == "" {
		c.SmartwinData = autoDetectData()
	}
	if c.HTTPPort == 0 {
		c.HTTPPort = 8080
	}
	if c.HTTPSPort == 0 {
		c.HTTPSPort = 8443
	}
	if c.RefreshMinutes == 0 {
		c.RefreshMinutes = 3
	}
	if c.LabelWidth == 0 {
		c.LabelWidth = 450
	}
	if c.StoreNo == "" {
		c.StoreNo = "1"
	}
	return c
}

func saveConfig(c Config) error {
	b, _ := json.MarshalIndent(c, "", "  ")
	return os.WriteFile(configPath(), b, 0644)
}

func workDir() string {
	if runtime.GOOS == "windows" {
		return `C:\SVScan`
	}
	d := os.Getenv("SVSCAN_WORK")
	if d == "" {
		d = "/tmp/svscan"
	}
	return d
}

func autoDetectData() string {
	if runtime.GOOS != "windows" {
		if d := os.Getenv("SVSCAN_DATA"); d != "" {
			return d
		}
		return ""
	}
	candidates := []string{
		`C:\Smartwin\Data`,
		`C:\SmartVendor\Data`,
		`C:\SV\Data`,
		`D:\Smartwin\Data`,
	}
	for _, c := range candidates {
		if _, err := os.Stat(filepath.Join(c, "svMain", "stkprice.MYD")); err == nil {
			return c
		}
	}
	return `C:\Smartwin\Data`
}
