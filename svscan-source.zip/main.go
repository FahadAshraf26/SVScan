package main

import (
	"crypto/tls"
	"embed"
	"fmt"
	"net/http"
	"os"
	"strconv"
	"time"
)

//go:embed web/index.html web/html5-qrcode.min.js
var webFS embed.FS

const version = "1.0.0"

func main() {
	fmt.Println("SVScan", version, "- Smart Vendor phone scanner + shelf-tag printer")
	if err := os.MkdirAll(workDir(), 0755); err != nil {
		fmt.Println("cannot create work dir:", err)
	}

	cfg := loadConfig()
	_ = saveConfig(cfg)

	srv := &Server{cfg: cfg, catalog: &Catalog{byCode: map[string]*Item{}}}

	fmt.Println("Data source :", cfg.SmartwinData)
	fmt.Println("Store number:", cfg.StoreNo)
	fmt.Println("Work dir    :", workDir())

	// initial load
	srv.refresh()
	go srv.refreshLoop()

	mux := srv.routes()
	ip := primaryIP()

	// Plain HTTP: redirect to HTTPS (phone camera requires a secure origin).
	go func() {
		httpAddr := ":" + strconv.Itoa(cfg.HTTPPort)
		redir := http.NewServeMux()
		redir.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
			target := "https://" + hostOnly(r.Host, ip) + ":" + strconv.Itoa(cfg.HTTPSPort) + r.URL.RequestURI()
			http.Redirect(w, r, target, http.StatusTemporaryRedirect)
		})
		fmt.Printf("HTTP  (redirect) on http://%s:%d\n", ip, cfg.HTTPPort)
		_ = http.ListenAndServe(httpAddr, redir)
	}()

	cert, err := selfSignedCert()
	if err != nil {
		fmt.Println("TLS cert error:", err)
		os.Exit(1)
	}
	httpsAddr := ":" + strconv.Itoa(cfg.HTTPSPort)
	server := &http.Server{
		Addr:         httpsAddr,
		Handler:      mux,
		TLSConfig:    &tls.Config{Certificates: []tls.Certificate{cert}},
		ReadTimeout:  20 * time.Second,
		WriteTimeout: 30 * time.Second,
	}

	fmt.Println("=====================================================")
	fmt.Printf(" Open this on your phone (same Wi-Fi):\n")
	fmt.Printf("   https://%s:%d\n", ip, cfg.HTTPSPort)
	fmt.Println(" (Accept the security warning once — it is your own")
	fmt.Println("  server's certificate. This is needed for the camera.)")
	fmt.Println("=====================================================")

	if err := server.ListenAndServeTLS("", ""); err != nil {
		fmt.Println("server error:", err)
		os.Exit(1)
	}
}

func hostOnly(hostPort, fallback string) string {
	for i := 0; i < len(hostPort); i++ {
		if hostPort[i] == ':' {
			return hostPort[:i]
		}
	}
	if hostPort == "" {
		return fallback
	}
	return hostPort
}
