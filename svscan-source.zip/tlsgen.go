package main

import (
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"math/big"
	"net"
	"os"
	"path/filepath"
	"time"
)

// selfSignedCert loads a cached self-signed cert or creates one covering the
// server's LAN IPs, localhost and hostname. Phone camera access needs HTTPS.
func selfSignedCert() (tls.Certificate, error) {
	certPath := filepath.Join(workDir(), "svscan_cert.pem")
	keyPath := filepath.Join(workDir(), "svscan_key.pem")

	if cb, err := os.ReadFile(certPath); err == nil {
		if kb, err := os.ReadFile(keyPath); err == nil {
			if cert, err := tls.X509KeyPair(cb, kb); err == nil {
				return cert, nil
			}
		}
	}

	priv, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return tls.Certificate{}, err
	}
	serial, _ := rand.Int(rand.Reader, new(big.Int).Lsh(big.NewInt(1), 128))
	tmpl := x509.Certificate{
		SerialNumber:          serial,
		Subject:               pkix.Name{CommonName: "SVScan", Organization: []string{"SVScan Local"}},
		NotBefore:             time.Now().Add(-time.Hour),
		NotAfter:              time.Now().AddDate(10, 0, 0),
		KeyUsage:              x509.KeyUsageDigitalSignature | x509.KeyUsageKeyEncipherment,
		ExtKeyUsage:           []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
		BasicConstraintsValid: true,
	}
	host, _ := os.Hostname()
	if host != "" {
		tmpl.DNSNames = append(tmpl.DNSNames, host)
	}
	tmpl.DNSNames = append(tmpl.DNSNames, "localhost")
	tmpl.IPAddresses = append(tmpl.IPAddresses, net.ParseIP("127.0.0.1"))
	for _, ip := range lanIPv4s() {
		tmpl.IPAddresses = append(tmpl.IPAddresses, net.ParseIP(ip))
	}

	der, err := x509.CreateCertificate(rand.Reader, &tmpl, &tmpl, &priv.PublicKey, priv)
	if err != nil {
		return tls.Certificate{}, err
	}
	certPem := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der})
	keyDer, _ := x509.MarshalECPrivateKey(priv)
	keyPem := pem.EncodeToMemory(&pem.Block{Type: "EC PRIVATE KEY", Bytes: keyDer})
	_ = os.WriteFile(certPath, certPem, 0600)
	_ = os.WriteFile(keyPath, keyPem, 0600)
	return tls.X509KeyPair(certPem, keyPem)
}

func lanIPv4s() []string {
	var out []string
	ifaces, err := net.Interfaces()
	if err != nil {
		return out
	}
	for _, ifc := range ifaces {
		if ifc.Flags&net.FlagUp == 0 || ifc.Flags&net.FlagLoopback != 0 {
			continue
		}
		addrs, _ := ifc.Addrs()
		for _, a := range addrs {
			var ip net.IP
			switch v := a.(type) {
			case *net.IPNet:
				ip = v.IP
			case *net.IPAddr:
				ip = v.IP
			}
			if ip == nil || ip.To4() == nil || ip.IsLoopback() {
				continue
			}
			out = append(out, ip.String())
		}
	}
	return out
}

func primaryIP() string {
	ips := lanIPv4s()
	// prefer private ranges
	for _, ip := range ips {
		if len(ip) >= 3 && (ip[:3] == "192" || ip[:3] == "10." || ip[:3] == "172") {
			return ip
		}
	}
	if len(ips) > 0 {
		return ips[0]
	}
	return "127.0.0.1"
}
