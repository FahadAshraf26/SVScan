================================================================
  SVScan  —  Phone shelf scanner + tag printer for Smart Vendor
================================================================

WHAT IT DOES
------------
Runs on your Smart Vendor server. From any phone on the same
Wi-Fi you can:
  • Scan a barcode (or type a number) and instantly see the
    item's PRICE and QUANTITY ON HAND.
  • Print a corrected shelf tag on your TLP 2824 label printer.
    The tag matches Smart Vendor: description, price, UPC,
    reorder #, and a barcode of the stock #.

It is READ-ONLY and passwordless. It never logs into your live
database and never changes anything. It just reads a copy of the
item tables every few minutes. Your POS is untouched.


ONE-TIME SETUP  (about 2 minutes)
---------------------------------
1. Put SVScan.exe anywhere on the SERVER (e.g. C:\SVScan\ or the
   Desktop). Double-click it.  A black window opens and shows a
   line like:

        Open this on your phone (same Wi-Fi):
           https://192.168.2.76:8443

2. The FIRST time, Windows may ask "Allow SVScan to communicate
   on your network?" — click ALLOW (Private networks). This lets
   your phone reach it.  (Leave the black window open/minimized —
   that IS the program running.)

3. On your PHONE (connected to the store Wi-Fi), open a browser
   and go to the https address shown (e.g. https://192.168.2.76:8443).
   You'll see a "connection is not private" warning — that's normal,
   it's your own server's certificate.  Tap Advanced → Proceed.
   The camera only works over https, which is why we accept this.

4. Tap the ⚙️ Settings section once, choose your TLP 2824 from the
   printer list, and tap "Save settings".  Done.

Tip: bookmark the page / add it to your home screen for one-tap access.


DAILY USE
---------
• Tap "Start camera", allow camera access, hold a barcode steady
  in view. Price + quantity pop up instantly. Use 🔦 for the
  flashlight, and the camera drop-down if you have more than one
  camera.  (No camera? Just type the number and tap Look up.)
• Manual search works by BARCODE, ITEM # (stock #), or REORDER #
  — including alternate reorder numbers from any supplier.
• To fix a wrong shelf tag: pick the printer, choose how many
  copies, tap "Print shelf tag".


TWO (OR MORE) PRINTERS
----------------------
• Both printers must be visible to Windows on the server.
  - A printer plugged into THIS server shows up automatically.
  - A printer on ANOTHER computer: on that computer, share the
    printer (Printer properties -> Sharing -> Share this printer).
    Then on the server either "Add a printer" -> choose the shared
    one (it will then appear in the list), OR just type its share
    name in Settings, e.g.  \\OTHER-PC\ZebraShareName
• Two identical TLP 2824s look the same in the list. In Settings,
  select one and tap "Test print" — a small SVScan TEST label
  comes out of that exact printer, so you know which is which.
• On the item screen you can also pick which printer to send each
  tag to, so you can print to either one on the fly.


KEEP IT RUNNING / AUTO-START (optional)
---------------------------------------
The program must be running for phones to connect.
To start it automatically when the server boots:
  1. Press Windows+R, type:  shell:startup   and press Enter.
  2. Right-drag SVScan.exe into that folder → "Create shortcut here".
Now it launches on every login.


GOOD TO KNOW
------------
• Data refreshes every ~3 minutes, so price/quantity are current
  to within a few minutes — perfect for checking shelf tags.
• A brand-new item added in Smart Vendor minutes ago might not
  appear until the next refresh.
• Settings are saved in C:\SVScan\svscan_config.json (store #,
  printer, label width). You can edit it if ever needed.
• If the black window says it "cannot read stkprice.MYD", make
  sure Smart Vendor is installed at C:\Smartwin. If it's elsewhere,
  open svscan_config.json and set "smartwinData" to your ...\Data
  folder, then restart SVScan.exe.

Nothing here modifies Smart Vendor, MySQL, or your data.
