package main

import (
	"strings"
	"sync"
	"time"
)

// Item is a fully resolved catalog item (identity + live price/qty).
type Item struct {
	StockNo   string  `json:"stockNo"`
	StockID   string  `json:"stockId"`
	Name      string  `json:"name"`
	Name2     string  `json:"name2"`
	ReorderNo string  `json:"reorderNo"`
	UPC       string  `json:"upc"`
	UPC2      string  `json:"upc2"`
	UPC3      string  `json:"upc3"`
	Dept      string  `json:"dept"`
	SubDept   string  `json:"subDept"`
	Supp      string  `json:"supplier"`
	AllReorders []string `json:"allReorders,omitempty"`

	SellPrice float64 `json:"sellPrice"`
	SalePrice float64 `json:"salePrice"`
	ListPrice float64 `json:"listPrice"`
	Qty       float64 `json:"qty"`
	QtyReport float64 `json:"-"`
	SaleStart int64   `json:"-"`
	SaleEnd   int64   `json:"-"`
	hasPrice  bool

	OnSale    bool    `json:"onSale"`
	EffPrice  float64 `json:"effPrice"`
	MatchedOn string  `json:"matchedOn,omitempty"`
}

// Catalog is the in-memory, refreshable index.
type Catalog struct {
	mu       sync.RWMutex
	byCode   map[string]*Item
	items    []*Item
	loadedAt time.Time
	count    int
	err      string
}

func nowPacked() int64 {
	t := time.Now()
	return int64(t.Year())*10000000000 +
		int64(t.Month())*100000000 +
		int64(t.Day())*1000000 +
		int64(t.Hour())*10000 +
		int64(t.Minute())*100 +
		int64(t.Second())
}

// computeSale sets OnSale / EffPrice on an item.
func (it *Item) computeSale(now int64) {
	it.EffPrice = it.SellPrice
	it.OnSale = false
	if it.SalePrice > 0 && it.SaleStart > 0 && it.SaleEnd > 0 &&
		it.SaleStart <= now && now <= it.SaleEnd {
		it.OnSale = true
		it.EffPrice = it.SalePrice
	}
}

// normKeys returns the set of lookup keys for a raw barcode string.
func normKeys(s string) []string {
	s = strings.TrimSpace(s)
	if s == "" {
		return nil
	}
	keys := map[string]bool{}
	add := func(k string) {
		k = strings.TrimSpace(k)
		if k != "" {
			keys[strings.ToUpper(k)] = true
		}
	}
	add(s)
	// strip leading zeros
	trimmed := strings.TrimLeft(s, "0")
	if trimmed == "" {
		trimmed = "0"
	}
	add(trimmed)
	// If 13-digit EAN with leading 0 -> 12-digit UPC-A
	if len(s) == 13 && strings.HasPrefix(s, "0") {
		add(s[1:])
	}
	// If 12-digit -> also 13 with leading 0
	if len(s) == 12 {
		add("0" + s)
	}
	out := make([]string, 0, len(keys))
	for k := range keys {
		out = append(out, k)
	}
	return out
}

// buildIndex indexes items by every barcode / id form.
func buildIndex(items []*Item) map[string]*Item {
	idx := make(map[string]*Item, len(items)*3)
	put := func(raw string, it *Item) {
		for _, k := range normKeys(raw) {
			if _, exists := idx[k]; !exists {
				idx[k] = it
			}
		}
	}
	// index primary barcodes first so they win over ids on collisions
	for _, it := range items {
		put(it.UPC, it)
		put(it.UPC2, it)
		put(it.UPC3, it)
	}
	for _, it := range items {
		put(it.StockID, it)
		put(it.ReorderNo, it)
		for _, ro := range it.AllReorders {
			put(ro, it)
		}
	}
	return idx
}

func (c *Catalog) lookup(code string) (*Item, bool) {
	c.mu.RLock()
	defer c.mu.RUnlock()
	for _, k := range normKeys(code) {
		if it, ok := c.byCode[k]; ok {
			cp := *it
			cp.computeSale(nowPacked())
			tc := strings.TrimSpace(code)
			isReorder := strings.EqualFold(cp.ReorderNo, tc)
			for _, ro := range cp.AllReorders {
				if strings.EqualFold(ro, tc) {
					isReorder = true
				}
			}
			switch {
			case cp.UPC != "" && strings.EqualFold(strings.TrimLeft(cp.UPC, "0"), strings.TrimLeft(code, "0")):
				cp.MatchedOn = "UPC"
			case strings.EqualFold(cp.StockID, tc):
				cp.MatchedOn = "Stock #"
			case isReorder:
				cp.MatchedOn = "Reorder #"
			default:
				cp.MatchedOn = "barcode"
			}
			return &cp, true
		}
	}
	return nil, false
}

func (c *Catalog) byStockNo(stockno string) (*Item, bool) {
	c.mu.RLock()
	defer c.mu.RUnlock()
	for _, it := range c.items {
		if it.StockNo == stockno {
			cp := *it
			cp.computeSale(nowPacked())
			return &cp, true
		}
	}
	return nil, false
}

func (c *Catalog) stats() (int, time.Time, string) {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return c.count, c.loadedAt, c.err
}
