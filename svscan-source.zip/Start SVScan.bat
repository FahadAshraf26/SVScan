@echo off
title SVScan - Shelf Scanner (leave this window open)
cd /d "%~dp0"
echo Starting SVScan...  Leave this window open while you use the scanner.
echo.
SVScan.exe
echo.
echo SVScan stopped. Press any key to close.
pause >nul
