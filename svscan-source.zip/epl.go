package main

import (
	"fmt"
	"strings"
)

// eplEscape sanitizes a string for inclusion inside an EPL2 quoted field.
func eplEscape(s string) string {
	s = strings.Map(func(r rune) rune {
		if r < 32 || r == 127 {
			return -1
		}
		return r
	}, s)
	s = strings.ReplaceAll(s, `\`, `\\`)
	s = strings.ReplaceAll(s, `"`, `\"`)
	return s
}

func money(v float64) string {
	return fmt.Sprintf("%.2f", v)
}

// LabelOptions controls what goes on the tag.
type LabelOptions struct {
	Qty        int
	UseSale    bool // print sale price + SALE marker
	Width      int  // dots (q). default 450 (~2.25")
	GapDivider int
}

// buildTestEPL prints a small identification label so two identical TLP 2824s
// can be told apart.
func buildTestEPL(name string, width int) []byte {
	if width == 0 {
		width = 450
	}
	if len(name) > 26 {
		name = name[:26]
	}
	var b strings.Builder
	b.WriteString("\r\nN\r\nD13\r\n")
	b.WriteString(fmt.Sprintf("q%d\r\n", width))
	b.WriteString("Q203,26\r\n")
	b.WriteString("A20,15,0,4,1,1,N,\"SVScan TEST\"\r\n")
	b.WriteString(fmt.Sprintf("A20,70,0,3,1,1,N,\"%s\"\r\n", eplEscape(name)))
	b.WriteString("A20,110,0,2,1,1,N,\"printer OK\"\r\n")
	b.WriteString("P1\r\n")
	return []byte(b.String())
}

// buildEPL renders a shelf tag matching Smart Vendor's
// "Elt2824_Stk_1up_1Price_Shelf_ReorderNo" template for the TLP 2824.
func buildEPL(it *Item, opt LabelOptions) []byte {
	qty := opt.Qty
	if qty < 1 {
		qty = 1
	}
	width := opt.Width
	if width == 0 {
		width = 450
	}

	desc := it.Name
	if desc == "" {
		desc = it.Name2
	}
	if len(desc) > 30 {
		desc = desc[:30]
	}
	reorder := it.ReorderNo
	if len(reorder) > 18 {
		reorder = reorder[:18]
	}
	stockBar := it.StockID
	if stockBar == "" {
		stockBar = it.ReorderNo
	}
	if stockBar == "" {
		stockBar = it.StockNo
	}
	stockBar = strings.ToUpper(strings.TrimSpace(stockBar))

	price := it.SellPrice
	onSale := opt.UseSale && it.SalePrice > 0

	var b strings.Builder
	b.WriteString("\r\nN\r\n")
	b.WriteString("D13\r\n")
	b.WriteString(fmt.Sprintf("q%d\r\n", width))
	b.WriteString("Q203,26\r\n")

	// Description
	b.WriteString(fmt.Sprintf("A5,6,0,3,1,2,N,\"%s\"\r\n", eplEscape(desc)))
	if it.Name2 != "" && it.Name != "" {
		d2 := it.Name2
		if len(d2) > 30 {
			d2 = d2[:30]
		}
		b.WriteString(fmt.Sprintf("A5,34,0,2,1,1,N,\"%s\"\r\n", eplEscape(d2)))
	}
	// UPC line
	if it.UPC != "" {
		b.WriteString(fmt.Sprintf("A5,58,0,2,1,1,N,\"UPC: %s\"\r\n", eplEscape(it.UPC)))
	}
	// Reorder number (top-right)
	if reorder != "" {
		b.WriteString(fmt.Sprintf("A250,10,0,2,1,1,N,\"#%s\"\r\n", eplEscape(reorder)))
	}

	// Price (large, right side)
	if onSale {
		b.WriteString("A300,40,0,2,1,1,R,\"SALE\"\r\n")
		b.WriteString(fmt.Sprintf("A250,70,0,4,1,2,N,\"$%s\"\r\n", eplEscape(money(it.SalePrice))))
	} else {
		b.WriteString(fmt.Sprintf("A250,70,0,4,1,2,N,\"$%s\"\r\n", eplEscape(money(price))))
	}

	// Code 39 barcode of stock number, human readable underneath.
	b.WriteString(fmt.Sprintf("B10,120,0,3,2,4,60,B,\"%s\"\r\n", eplEscape(stockBar)))

	b.WriteString(fmt.Sprintf("P%d\r\n", qty))
	return []byte(b.String())
}
